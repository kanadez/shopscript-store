<?php

class shopReportsOrderItemListAction extends shopReportsOrderListAction
{}